package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Random;

public class testcest {
	
	
	public  String encryption(String word) {
	
	Random random = new Random();   
	
	int n1 = random.nextInt(10);  
	int n2 = random.nextInt(10);  
	int n3 = random.nextInt(10); 
	ArrayList<String> enctext = new ArrayList<String>();
	String password = word;
	
	char[] stringToChar = password.toCharArray();
	
	
	for(int i=2;i<= stringToChar.length;i=i+3) {
				
			for(int j = i-1;j<=stringToChar.length-2; j=i+2 ) {
						
				for(int k = j-1;k<=stringToChar.length-3; k=i+1 ) {
					
					  int ascvalue = (int) stringToChar[k];
					  int ascvalue1 = ascvalue+n1;
					  String asc= Integer.toString(ascvalue1);
					  byte[] encodedBytes =Base64.getEncoder().encode(asc.getBytes()); 
					  String text = new String(encodedBytes);
					  enctext.add(text);
					  break;
					
				}
				
				  int ascvalue = (int) stringToChar[j];
				  int ascvalue1 = ascvalue+n2; 
				  String asc= Integer.toString(ascvalue1);
				  byte[] encodedBytes = Base64.getEncoder().encode(asc.getBytes()); 
				  String text = new String(encodedBytes);
				  enctext.add(text);
				  break;
			}
			if( i >= stringToChar.length ) {
				break;
			}else {
			  int ascvalue = (int) stringToChar[i];
              int ascvalue1 = ascvalue+n3; 
              String asc= Integer.toString(ascvalue1); 
			  byte[] encodedBytes =Base64.getEncoder().encode(asc.getBytes());
			  String text = new String(encodedBytes);
			  enctext.add(text);
			}
	}
	
    System.out.println(enctext);
    String str = String.join(",", enctext);
     
	return str;
	
}
	

}
